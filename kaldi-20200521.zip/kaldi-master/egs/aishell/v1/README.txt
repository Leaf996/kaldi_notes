The database can be downloaded from openslr:
http://www.openslr.org/33/

For more details, please visit:
http://www.aishelltech.com/kysjcp

We use the training set to train model,
and split the test set into enroll and eval.
