This recipe is JHU's submission to the ASpIRE challenge. It uses
Fisher-English corpus for training the acoustic and language models.
It uses impulse responses and noises from RWCP, AIR and Reverb2014 
databases to create multi-condition data
